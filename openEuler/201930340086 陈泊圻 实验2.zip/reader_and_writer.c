#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

sem_t mutex1,mutex2,mutex3,w,r;
int read_count = 0, write_count = 0, reading = 0, writing = 0;


void reader()
{
    while(1)
    {
        srand(time(0)); sleep(1+rand()%3);
        sem_wait(&mutex3);  //保证writer到来时最多等待1个reader
        sem_wait(&r);       //是否可以read（有无writer）
        sem_wait(&mutex1);  //是否可以修改read_count
        read_count++;
        if(read_count == 1) sem_wait(&w);  //第一个读者，锁写者
        sem_post(&mutex1);
        sem_post(&r);
        sem_post(&mutex3);

        reading++;
        int curr_reading = reading, curr_writing = writing;
        printf("-------------------------------------------------------------------------------\n"); 
        printf("读者正在读取数据\t\t\t在读人数为：%d，在写人数为：%d\n",curr_reading,curr_writing);
        srand(time(0)); sleep(1+rand()%5);
        reading--;

        sem_wait(&mutex1);
        read_count--;
        if(read_count == 0) sem_post(&w);   //没有读者，释放写者
        sem_post(&mutex1);
    }
}

void writer()
{
    while(1)
    {
        srand(time(0)); sleep(1+rand()%3);

        sem_wait(&mutex2);  //是否可以修改write_count
        write_count++;
        if(write_count == 1) sem_wait(&r);  //第一个写者，锁读者
        sem_post(&mutex2);
        
        sem_wait(&w);       //是否可以write（有无reader或其他writer）
        writing++;
        int curr_reading = reading, curr_writing = writing;
        printf("-------------------------------------------------------------------------------\n");
        printf("写者正在写入数据\t\t\t在读人数为：%d，在写人数为：%d\n",curr_reading,curr_writing);
        srand(time(0)); sleep(1+rand()%2);
        writing--;
        sem_post(&w);

        sem_wait(&mutex2);
        write_count--;
        if(write_count == 0) sem_post(&r);  //没有写者，释放读者
        sem_post(&mutex2);
    }
}

int main()
{
    sem_init(&mutex1, 0, 1);
    sem_init(&mutex2, 0, 1);
    sem_init(&mutex3, 0, 1);
    sem_init(&r, 0, 1);
    sem_init(&w, 0, 1);

    pthread_t tid[6];   //3个reader，2个writer
    pthread_create(&tid[0], NULL, reader, NULL);
    pthread_create(&tid[1], NULL, reader, NULL);
    pthread_create(&tid[2], NULL, reader, NULL);
    pthread_create(&tid[3], NULL, reader, NULL);
    pthread_create(&tid[4], NULL, writer, NULL);
    pthread_create(&tid[5], NULL, writer, NULL);

    for(int i=0;i<4;i++)
        pthread_join(tid[i], NULL);

    sem_destroy(&mutex1);
    sem_destroy(&mutex2);
    sem_destroy(&mutex3);
    sem_destroy(&r);
    sem_destroy(&w);
}