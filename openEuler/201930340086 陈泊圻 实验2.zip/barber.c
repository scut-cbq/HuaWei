#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

#define N 5     //接待室有5张椅子

int chairs = N;
sem_t customer,mutex;

void Barber()
{
    while(1)
    {
        sem_wait(&mutex);
        if(chairs == N) printf("没有客人，理发师睡觉\n");   
        sem_post(&mutex);

        sem_wait(&customer);    //看有没有客人
        sem_wait(&mutex);        //修改chairs
        chairs++;
        printf("理发师接待一名客人，空座位加1，此时空座位数为%d\n", chairs);
        sem_post(&mutex);
        sleep(2);               //剪头发，一个剪2秒
    }
}

void Customer()
{
    while(1)
    {
        sem_post(&customer);    //告诉理发师有新客人
        sem_wait(&mutex);
        chairs--;
        if(chairs < 0)
        {
            printf("没有空座位了，顾客离开\n");
            chairs++;
        }
        else
            printf("客人坐下了，此时空座位数为%d\n", chairs);
        sem_post(&mutex);
        sleep(rand() % 2);  //每0~2秒来一个客人
    }
}

int main()
{
    srand(time(0));
    sem_init(&customer, 0, 0);   //一开始没有客人
    sem_init(&mutex, 0, 1);
    pthread_t tid[2];
    pthread_create(&tid[0], NULL, Barber, NULL);
    sleep(1);
    pthread_create(&tid[1], NULL, Customer, NULL);

    for(int i=0;i<2;i++)
        pthread_join(tid[i], NULL);

    sem_destroy(&customer);
    sem_destroy(&mutex);
}