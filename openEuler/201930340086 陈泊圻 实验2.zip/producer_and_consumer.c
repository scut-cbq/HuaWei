#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <time.h>

#define N 100       //缓冲区大小    
sem_t mutex,empty,full;
char buffer[N];
int curr = 0;       //缓冲区指针

void producer1()    //生成大写字母
{
    while (1)
    {
        char ch = 'A' + rand() % 26;    //produce item
        sem_wait(&empty);               //DOWN
        sem_wait(&mutex);
        buffer[curr++] = ch;            //写入缓冲区
        printf("-------------------------------------------------------------\n");
        printf("生产者1生产大写字母%c写入缓冲区，此时缓冲区为\n%s\n", ch, buffer);
        sem_post(&mutex);               //UP
        sem_post(&full);
        sleep(1);
    }
}

void producer2()    //生成小写字母
{
    while (1)
    {
        char ch = 'a' + rand() % 26;    //produce item
        sem_wait(&empty);               //DOWN
        sem_wait(&mutex);
        buffer[curr++] = ch;            //写入缓冲区
        printf("-------------------------------------------------------------\n");
        printf("生产者2生产小写字母%c写入缓冲区，此时缓冲区为\n%s\n", ch, buffer);
        sem_post(&mutex);               //UP
        sem_post(&full);
        sleep(1);
    }
}

void consumer1()    //消费大写字母
{
    while(1)
    {
        sem_wait(&full);
        sem_wait(&mutex);
        char ch = buffer[curr - 1];
        if(ch >= 'A' && ch <= 'Z')
        {
            buffer[--curr] = '\0';      //remove item
            printf("-------------------------------------------------------------\n");
            printf("消费者1消费大写字母%c，此时缓冲区为\n%s\n", ch, buffer);
        }
        sem_post(&mutex);
        sem_post(&empty);
        sleep(4);
    }
}

void consumer2()    //消费小写字母
{
    while(1)
    {
        sem_wait(&full);
        sem_wait(&mutex);
        char ch = buffer[curr - 1];
        if(ch >= 'a' && ch <= 'z')
        {
            buffer[--curr] = '\0';      //remove item
            printf("-------------------------------------------------------------\n");
            printf("消费者2消费小写字母%c，此时缓冲区为\n%s\n", ch, buffer);
        }
        sem_post(&mutex);
        sem_post(&empty);
        sleep(4);
    }
}

void consumer3()    //消费任意字母
{
    while(1)
    {
        sem_wait(&full);
        sem_wait(&mutex);
        char ch = buffer[curr - 1];
        buffer[--curr] = '\0';      //remove item
        printf("-------------------------------------------------------------\n");
        printf("消费者3消费字母%c，此时缓冲区为\n%s\n", ch, buffer);
        sem_post(&mutex);
        sem_post(&empty);
        sleep(4);
    }
}

int main()
{
    srand(time(0));
    int i;
    for(i = 0; i < N; i++)
        buffer[i] = '\0';
    sem_init(&mutex, 0, 1);
    sem_init(&empty, 0, N);
    sem_init(&full, 0, 0);

    
    pthread_t tid[5];
    if(pthread_create(&tid[0], NULL, producer1, NULL)) printf("生产者1创建失败\n");
    if(pthread_create(&tid[1], NULL, producer2, NULL)) printf("生产者2创建失败\n");
    if(pthread_create(&tid[4], NULL, consumer1, NULL)) printf("消费者1创建失败\n");
    if(pthread_create(&tid[3], NULL, consumer2, NULL)) printf("消费者2创建失败\n");
    if(pthread_create(&tid[4], NULL, consumer3, NULL)) printf("消费者3创建失败\n");
    
    for(i = 0; i < 5; i++)
        pthread_join(tid[i], NULL);
    
    sem_destroy(&mutex);
    sem_destroy(&empty);
    sem_destroy(&full);

    return 0;
}