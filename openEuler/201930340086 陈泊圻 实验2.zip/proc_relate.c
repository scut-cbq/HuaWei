#include <linux/init.h>		/* __init and __exit macroses */
#include <linux/kernel.h>	/* KERN_INFO macros */
#include <linux/module.h>	/* required for all kernel modules */
#include <linux/moduleparam.h>	/* module_param() and MODULE_PARM_DESC() */

#include <linux/fs.h>		/* struct file_operations, struct file */
#include <linux/miscdevice.h>	/* struct miscdevice and misc_[de]register() */
#include <linux/slab.h>		/* kzalloc() function */
#include <linux/uaccess.h>	/* copy_{to,from}_user() */
#include <linux/init_task.h>    //init_task再次定义
#include "proc_relate.h"
#include <linux/delay.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Wu Yimin>");
MODULE_DESCRIPTION("proc_relate kernel modoule");

static int proc_relate_open(struct inode *inode, struct file *file) {
	struct proc_info *buf;
	int err = 0;
	buf=kmalloc(sizeof(struct proc_info)*30,GFP_KERNEL);
	
	file->private_data = buf;
	return err;
}

static ssize_t proc_relate_read(struct file *file, char __user * out,size_t size, loff_t * off) {
	struct proc_info *buf = file->private_data;
	msleep(100);	//睡一会，让用户空间的进程输出完先
    unsigned int curr_sessionid = current->sessionid;   //取当前进程的会话号
	struct list_head* pos;			//list_for_each中的当前项
	struct task_struct *p, *task = &init_task;
    int cnt = 0;					//用于记录读取了多少个task_struct
	list_for_each(pos,&task->tasks)	//遍历所有task_struct
	{
		p = list_entry(pos,struct task_struct,tasks);	//根据struct list_head tasks获得task_struct的地址
		if(p->sessionid == curr_sessionid)				//只取当前会话的进程的信息
        {
            buf->state = p->state;
            buf->pid = p->pid;
            buf->tgid = p->tgid;
            strncpy(buf->comm, p->comm, sizeof(buf->comm));
            buf->prio = p->prio;
            buf->static_prio = p->static_prio;
            buf->mm = p->mm;
            buf->active_mm = p->active_mm;
            buf->sessionid = p->sessionid;
            buf->real_parent = p->real_parent->pid;
            buf->parent = p->parent->pid;
            buf->group_leader = p->group_leader->pid;
            buf++;										
            cnt++;
        }
	}
	int len = cnt*sizeof(struct proc_info) > size ? size : cnt*sizeof(struct proc_info);	//取读取字节数和size中较小的一个
    int wrong_bytes = copy_to_user(out, file->private_data, len);
    if(wrong_bytes)
        printk(KERN_INFO "读取失败，失败的字节数%d\n",wrong_bytes);
	return len;		//返回读取到的字节数
}

static int proc_relate_close(struct inode *inode, struct file *file) {
	struct buffer *buf = file->private_data;
	kfree(buf);
	return 0;
}

static struct file_operations proc_relate_fops = {
	.owner = THIS_MODULE,
	.open = proc_relate_open,
	.read = proc_relate_read,
	.release = proc_relate_close,
	.llseek = noop_llseek
};

static struct miscdevice proc_relate_misc_device = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "proc_relate",
	.fops = &proc_relate_fops
};

static int __init proc_relate_init(void) {

	misc_register(&proc_relate_misc_device);
	printk(KERN_INFO
	       "proc_relate device has been registered.\n");

	return 0;
}

static void __exit proc_relate_exit(void)
{
	misc_deregister(&proc_relate_misc_device);
	printk(KERN_INFO "proc_relate device has been unregistered\n");
}

module_init(proc_relate_init);
module_exit(proc_relate_exit);
