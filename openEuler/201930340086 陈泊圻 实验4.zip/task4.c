SYSCALL_DEFINE1(proc_relate,char *,out) {
	//历遍系统中的所有进程，统计符合条件的进程数目
	int cnt = 2, cnt_bytes = 4;		//进程数目和读取到的字节数；先把当前进程和父进程算进去cnt，把int算进去cnt_bytes
	struct task_struct *task;
	struct list_head *list;
	list_for_each(list, &current->children)		//统计子进程数目
	{
		task = list_entry(list, struct task_struct, sibling);
		cnt++;
	}
	//根据进程数目，申请内存空间buffer，用于存放这些进程的相关信息
	char *buffer = kmalloc(sizeof(int)+sizeof(struct proc_info)*cnt, GFP_KERNEL);
	struct buf *b = (struct buf*)buffer;
	b->count = cnt;		//相关的进程数目
	struct proc_info *p = (struct proc_info*)(buffer+sizeof(int));
	//历遍系统中的所有进程，将符合条件的进程的相关信息保存在buffer
	//取当前进程信息
	task = current;
	p->state = task->state;
	p->pid = task->pid;
    p->tgid = task->tgid;
	if(task->comm) strncpy(p->comm, task->comm, sizeof(p->comm));
	p->prio = task->prio;
    p->static_prio = task->static_prio;
    p->mm = task->mm;
    p->active_mm = task->active_mm;
    p->real_parent = task->real_parent->pid;
    p->parent = task->parent->pid;
    p->group_leader = task->group_leader->pid;
	p++;
	cnt_bytes += sizeof(struct proc_info);
	
	//取父进程信息
	task = current->parent;
	p->state = task->state;
	p->pid = task->pid;
    p->tgid = task->tgid;
	strncpy(p->comm, task->comm, sizeof(p->comm));
	p->prio = task->prio;
    p->static_prio = task->static_prio;
    p->mm = task->mm;
    p->active_mm = task->active_mm;
    p->real_parent = task->real_parent->pid;
    p->parent = task->parent->pid;
    p->group_leader = task->group_leader->pid;
	p++;
	cnt_bytes += sizeof(struct proc_info);

	//取子进程信息
	list_for_each(list, &current->children)
	{
		task = list_entry(list, struct task_struct, sibling);
		p->state = task->state;
		p->pid = task->pid;
 	    p->tgid = task->tgid;
		strncpy(p->comm, task->comm, sizeof(p->comm));
		p->prio = task->prio;
    	p->static_prio = task->static_prio;
    	p->mm = task->mm;
  		p->active_mm = task->active_mm;
  	    p->real_parent = task->real_parent->pid;
  		p->parent = task->parent->pid;
  	  	p->group_leader = task->group_leader->pid;
		p++;
		cnt_bytes += sizeof(struct proc_info);
	}
	//将buffer的内容复制到用户空间：copy_to_user(out, buffer, size)
	int wrong_bytes = copy_to_user(out, buffer, cnt_bytes);
    if(wrong_bytes)
        printk(KERN_INFO "读取失败，失败的字节数%d\n",wrong_bytes);
	//释放buffer
	kfree(buffer);
	return cnt_bytes;
}