#include <linux/kernel.h>	/* KERN_INFO macros */
#include <linux/module.h>	/* required for all kernel modules */
#include <linux/fs.h>		/* struct file_operations, struct file */
#include <linux/miscdevice.h>	/* struct miscdevice and misc_[de]register() */
#include <linux/uaccess.h>	/* copy_{to,from}_user() */
#include <linux/init_task.h>    //init_task再次定义
#include "PageFrameStat.h"
#include <asm/page.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Wu Yimin>");
MODULE_DESCRIPTION("PageFramStat kernel modoule");


static int PageFramStat_open(struct inode *inode, struct file *file) {
	struct page_info *buf;
	int err = 0;
	buf=kmalloc(sizeof(struct page_info),GFP_KERNEL);
	
	file->private_data = buf;
	return err;
}

static ssize_t PageFramStat_read(struct file *file, char __user * out,size_t size, loff_t * off) {
	struct page_info *buf = file->private_data;
	ssize_t read_size = 0;

	buf->num_physpages = get_num_physpages();
	buf->free=buf->locked=buf->reserved=buf->swapcache=buf->referenced=buf->slab=buf->private=0;
	buf->uptodate=buf->dirty=buf->active=buf->writeback=buf->mappedtodisk=buf->valid=0;
	int i;

	int cnt = 0;
	for(i = 0; i < buf->num_physpages; i++)
	{
		struct page* p = pfn_to_page(ARCH_PFN_OFFSET + i);
		if(atomic_read(&p->_refcount) == 0) buf->free++;
		if(PageLocked(p)) buf->locked++;
		if(PageReserved(p)) buf->reserved++;
		if(PageSwapCache(p)) buf->swapcache++;
		if(PageReferenced(p)) buf->referenced++;
		if(PageSlab(p)) buf->slab++;
		if(PagePrivate(p)) buf->private++;
		if(PageUptodate(p)) buf->uptodate++;
		if(PageDirty(p)) buf->dirty++;
		if(PageActive(p)) buf->active++;
		if(PageWriteback(p)) buf->writeback++;
		if(PageMappedToDisk(p)) buf->mappedtodisk++;
		if(pfn_valid(ARCH_PFN_OFFSET + i)) cnt++;
	}
	read_size += sizeof(struct page_info);
	int wrong_bytes = copy_to_user(out, buf, size);
	if(wrong_bytes)
		printk(KERN_INFO "读取失败，失败的字节数%d\n",wrong_bytes);
	return read_size;
}

static int PageFramStat_close(struct inode *inode, struct file *file) {
	struct page_info *buf = file->private_data;
	kfree(buf);
	return 0;
}

static struct file_operations PageFramStat_fops = {
	.owner = THIS_MODULE,
	.open = PageFramStat_open,
	.read = PageFramStat_read,
	.release = PageFramStat_close,
	.llseek = noop_llseek
};

static struct miscdevice PageFramStat_misc_device = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "PageFramStat",
	.fops = &PageFramStat_fops
};

static int __init PageFramStat_init(void) {

	misc_register(&PageFramStat_misc_device);
	printk(KERN_INFO
	       "PageFramStat device has been registered.\n");

	return 0;
}

static void __exit PageFramStat_exit(void)
{
	misc_deregister(&PageFramStat_misc_device);
	printk(KERN_INFO "PageFramStat device has been unregistered\n");
}

module_init(PageFramStat_init);
module_exit(PageFramStat_exit);
