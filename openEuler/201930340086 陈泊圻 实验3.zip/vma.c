#include <linux/init.h>		/* __init and __exit macroses */
#include <linux/kernel.h>	/* KERN_INFO macros */
#include <linux/module.h>	/* required for all kernel modules */
#include <linux/moduleparam.h>	/* module_param() and MODULE_PARM_DESC() */

#include <linux/fs.h>		/* struct file_operations, struct file */
#include <linux/miscdevice.h>	/* struct miscdevice and misc_[de]register() */
#include <linux/slab.h>		/* kzalloc() function */
#include <linux/uaccess.h>	/* copy_{to,from}_user() */
#include "vma.h"
#include <linux/sched.h>
//#include <string.h>
#include <linux/dcache.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Wu Yimin>");
MODULE_DESCRIPTION("vma kernel modoule");

static int vma_open(struct inode *inode, struct file *file) {
	struct buffer *buf;
	int nvma=current->mm->map_count;
	int err = 0;
	buf=kmalloc(sizeof(struct buffer)+nvma*sizeof(struct vma_struct),GFP_KERNEL);

	file->private_data = buf;
	printk(KERN_INFO "Number of vma is %d\n",nvma);
 
	return err;
}

static ssize_t vma_read(struct file *file, char __user * out,size_t size, loff_t * off) {
	struct buffer *buf = file->private_data;
	ssize_t read_size = 0;

	struct task_struct *curr = current;
	buf->task_size = curr->mm->task_size;
	buf->highest_vm_end = curr->mm->highest_vm_end;
	buf->mm_users = atomic_read(&curr->mm->mm_users);
	buf->mm_count = atomic_read(&curr->mm->mm_count);
	buf->pgtables_bytes = atomic64_read(&curr->mm->pgtables_bytes);
	buf->map_count = curr->mm->map_count;
	buf->total_vm = curr->mm->total_vm;
	buf->locked_vm = atomic64_read(&curr->mm->locked_vm);
	buf->pinned_vm = curr->mm->pinned_vm;
	buf->data_vm = curr->mm->data_vm;
	buf->exec_vm = curr->mm->exec_vm;
	buf->stack_vm = curr->mm->stack_vm;
	buf->start_code = curr->mm->start_code;
	buf->end_code = curr->mm->end_code;
	buf->start_data = curr->mm->start_data;
	buf->end_data = curr->mm->end_data;
	buf->start_brk = curr->mm->start_brk;
	buf->brk = curr->mm->brk;
	buf->start_stack = curr->mm->start_stack;
	buf->arg_start = curr->mm->arg_start;
	buf->arg_end = curr->mm->arg_end;
	buf->env_start = curr->mm->env_start;
	buf->env_end = curr->mm->env_end;

	buf++; read_size += sizeof(struct buffer);
	if(read_size == size)	//只读取一个stuct buffer大小的数据，直接返回
	{
		int wrong_bytes = copy_to_user(out, file->private_data, read_size);
		if(wrong_bytes) printk(KERN_INFO "读取失败，失败的字节数%d\n",wrong_bytes);
		return read_size;
	}

	struct vma_struct *vma = (struct vma_struct*)buf;
	struct vm_area_struct *pos;
	for(pos = curr->mm->mmap; pos != NULL; pos = pos->vm_next)
	{
		vma->vm_start = pos->vm_start;
		vma->vm_end = pos->vm_end;
		vma->vm_flags = pos->vm_flags;
		if(pos->vm_file) {strncpy(vma->filename, pos->vm_file->f_path.dentry->d_iname, 200); vma->filename[199]='\0';}
		vma++; read_size += sizeof(struct vma_struct);
	}
	int wrong_bytes = copy_to_user(out, file->private_data, read_size);
	if(wrong_bytes) printk(KERN_INFO "读取失败，失败的字节数%d\n",wrong_bytes);
	return read_size;
}

static int vma_close(struct inode *inode, struct file *file) {
	struct buffer *buf = file->private_data;
	kfree(buf);
	return 0;
}

static struct file_operations vma_fops = {
	.owner = THIS_MODULE,
	.open = vma_open,
	.read = vma_read,
	.release = vma_close,
	.llseek = noop_llseek
};

static struct miscdevice vma_misc_device = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "vma",
	.fops = &vma_fops
};

static int __init vma_init(void) {

	misc_register(&vma_misc_device);
	printk(KERN_INFO
	       "vma device has been registered.\n");

	return 0;
}

static void __exit vma_exit(void)
{
	misc_deregister(&vma_misc_device);
	printk(KERN_INFO "vma device has been unregistered\n");
}

module_init(vma_init);
module_exit(vma_exit);
